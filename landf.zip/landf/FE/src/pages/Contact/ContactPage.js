import React, { Fragment } from "react";

const ContactPage = () => ( <
    Fragment >
    <
    div class = "signup-form" >
    <
    /
    div >
    <
    /Fragment>
);

export default ContactPage;