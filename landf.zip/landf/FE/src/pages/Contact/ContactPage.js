import React, { Fragment } from "react";

const ContactPage = () => ( <
    Fragment >
    <
    div class = "signup-form" >
    <
    p > under construction < /p> <
    /
    div >
    <
    /Fragment>
);

export default ContactPage;