import React, { Fragment } from "react";
import logo from "../../images/logo.gif";

const AboutPage = () => ( <
    Fragment >
    <
    div >




    <
    p align = "center" >
    <
    img src = { logo }
    alt = "cur"
    align = "center"
    height = { 200 }
    width = { 200 } >
    <
    /img> </p > <
    /
    div > <
    h1 align = "center" > Welcome to helpmelah.com < /h1>  

    <
    p > < /p> <
    p > < /p> <
    p > < /p>

    <
    div > <
    h2 align = "center" >
    Connecting residents of Singapore Help one another as a community Portal
    for Lost and Found Items <
    /h2>  < /
    div > <
    p > < /p><
    div > <
    h6 align = "center" > An intiative by NUS - ISS MTech 2021 - Team 8 students < /h6> < /
    div >

    <
    /Fragment>
);

export default AboutPage;