import React, { Fragment } from "react";

const FAQPage = () => ( <
    Fragment >
    <
    h2 > Frequently Asked Questions < /h2> <
    div class = "content" >
    <
    p > < /p> < /
    div > <
    h5 >
    What is helpmelah.com ? < /h5   > <
    p > to be updated. < /p>  

    <
    h5 >
    Where do I handover the item I found ? < /h5> <
    div class = "content" >
    <
    p > to be updated. < /p> < /
    div >

    <
    h5 >
    Where do I collect the item I lost ? < /h5> <
    div class = "content" >
    <
    p > to be updated. < /p> < /
    div >





    <
    /
    Fragment >
);

export default FAQPage;