import React, { Component } from "react";
import axios from 'axios';

export default class Login extends Component {

    constructor() {
        super();
        this.state = {
            username: '',
            password: ''
        };
    }

    onChange = e => {
        this.setState({
            [e.target.name]: e.target.value
        });
    };

    onSubmit = e => {
        e.preventDefault();

        const data = {
            username: this.state.username,
            password: this.state.password
        };

        axios
            .post('http://localhost:4000/userSignin', data)
            .then(res => {
                this.setState({
                    username: '',
                    password: ''
                })
                this.props.history.push('/');
            })
            .catch(err => {
                console.log("Error in Signin!");
            })
    };


    render() {
        return ( <
            form onSubmit = { this.onSubmit } >

            <
            div className = "container" >
            <
            div className = "row" >
            <
            div className = "col-md-6 m-auto" >
            <
            br / >

            <
            h4 > Sign In < /h4>

            <
            div className = "form-group" >
            <
            label > Email address < /label> <
            input type = "email"
            name = "username"
            className = "form-control"
            placeholder = "Enter email" / >
            <
            /div>

            <
            div className = "form-group" >
            <
            label > Password < /label> <
            input type = "password"
            name = "password"
            className = "form-control"
            placeholder = "Enter password" / >
            <
            /div>

            <
            div className = "form-group" >
            <
            div className = "custom-control custom-checkbox" >
            <
            input type = "checkbox"
            className = "custom-control-input"
            id = "customCheck1" / >
            <
            label className = "custom-control-label"
            htmlFor = "customCheck1" > Remember me < /label> < /
            div > <
            /div>

            <
            button type = "submit"
            className = "btn btn-primary btn-block" > Submit < /button>    <
            p className = "forgot-password text-left" >
            Not registered ? < a href = "./signup" > signup < /a> < /
            p >
            <
            /div> < /
            div > <
            /div> ></
            form >


        );
    }
}