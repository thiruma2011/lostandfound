import React, { Fragment } from "react";
import logo from "../../images/logo.gif";
const HomePage = () => ( <
    Fragment >
    <
    div >




    <
    /
    div > <
    h1 align = "center" > Welcome to helpmelah.com < /h1>  

    <
    div class = "container"
    align = "center" >
    <
    button type = "button"
    class = "btn btn-warning" > Lost Items < /button> <
    button type = "button"
    class = "btn btn-primary" > Found Items < /button> <
    button type = "button"
    class = "btn btn-secondary" > My Items < /button> <
    button type = "button"
    class = "btn btn-success" > Add Lost Item < /button> <
    button type = "button"
    class = "btn btn-info" > Add Found Item < /button>    < /
    div >



    <
    /Fragment>
);

export default HomePage;