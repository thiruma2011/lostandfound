import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import './App.css';
import axios from 'axios';


class CreateItem extends Component {
    constructor() {
        super();
        this.state = {
            title: '',
            description: '',
            stats: ''
        };
    }

    onChange = e => {
        this.setState({
            [e.target.name]: e.target.value
        });
    };

    onSubmit = e => {
        e.preventDefault();

        const data = {
            title: this.state.title,
            description: this.state.description,
            status: this.state.status
        };

        axios
            .post('http://localhost:4000/createItem', data)
            .then(res => {
                this.setState({
                    title: '',
                    description: '',
                    status: ''
                })
                this.props.history.push('/');
            })
            .catch(err => {
                console.log("Error in CreateItem!");
            })
    };

    render() {
        return ( <
            div className = "CreateItem" >
            <
            div className = "container" >
            <
            div className = "row" >
            <
            div className = "col-md-8 m-auto" >
            <
            br / >
            <
            Link to = "/viewitemslost"
            className = "btn btn-outline-warning float-left" >
            Show Item List Lost <
            /Link> < /
            div > <
            div className = "col-md-8 m-auto" >
            <
            h1 className = "display-4 text-center" > Add Item < /h1> <
            p className = "lead text-center" >
            Create new Item Found <
            /p>

            <
            form noValidate onSubmit = { this.onSubmit } >
            <
            div className = 'form-group' >
            <
            input type = 'text'
            placeholder = 'Category of the Item'
            name = 'title'
            className = 'form-control'
            value = { this.state.title }
            onChange = { this.onChange }
            /> < /
            div > <
            br / >

            <
            div className = 'form-group' >
            <
            input type = 'text'
            placeholder = 'Description'
            name = 'description'
            className = 'form-control'
            value = { this.state.description }
            onChange = { this.onChange }
            /> < /
            div >

            <
            div className = 'form-group' >
            <
            input type = 'text'
            placeholder = 'Status'
            name = 'status'
            className = 'form-control'
            value = { this.state.status }
            onChange = { this.onChange }
            /> < /
            div >

            <
            input type = "submit"
            className = "btn btn-outline-warning btn-block mt-4" /
            >
            <
            /form> < /
            div > <
            /div> < /
            div > <
            /div>
        );
    }
}

export default CreateItem;