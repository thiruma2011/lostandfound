import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import './App.css';
import axios from 'axios';


class CreateItemFound extends Component {
    constructor() {
        super();
        this.state = {
            category: '',
            summary: '',
            location: '',
            comments: '',
            date: '',
            contact: ''
        };
    }

    onChange = e => {
        this.setState({
            [e.target.name]: e.target.value
        });
    };

    onSubmit = e => {
        e.preventDefault();

        const data = {
            category: this.state.category,
            keyword: this.state.summary,
            location: this.state.location,
            comments: this.state.comments,
            date: this.state.date,
            contact: this.state.contact
        };

        axios
            .post('http://localhost:4000/createItemFound', data)
            .then(res => {
                this.setState({
                    category: '',
                    keyword: '',
                    location: '',
                    comments: '',
                    date: '',
                    contact: ''
                })
                this.props.history.push('/');
            })
            .catch(err => {
                console.log("Error in CreateItem!");
            })
    };

    render() {
        return ( <
            div className = "CreateItem" >
            <
            div className = "container" >
            <
            div className = "row" >
            <
            div className = "col-md-8 m-auto" >
            <
            br / >
            <
            Link to = "/viewitemslost"
            className = "btn btn-outline-warning float-left" >
            Show Item List Lost <
            /Link> < /
            div > <
            div className = "col-md-8 m-auto" >
            <
            h1 className = "display-4 text-center" > Add Item < /h1> <
            p className = "lead text-center" >
            Create new Item Found <
            /p>

            <
            form noValidate onSubmit = { this.onSubmit } >
            <
            div className = 'form-group' >
            <
            input type = 'text'
            placeholder = 'Category of the Item'
            name = 'category'
            className = 'form-control'
            value = { this.state.category }
            onChange = { this.onChange }
            /> < /
            div > <
            br / >

            <
            div className = 'form-group' >
            <
            input type = 'text'
            placeholder = 'Summary'
            name = 'summary'
            className = 'form-control'
            value = { this.state.summary }
            onChange = { this.onChange }
            /> < /
            div >

            <
            div className = 'form-group' >
            <
            input type = 'text'
            placeholder = 'Location'
            name = 'location'
            className = 'form-control'
            value = { this.state.location }
            onChange = { this.onChange }
            /> < /
            div >

            <
            div className = 'form-group' >
            <
            input type = 'text'
            placeholder = 'Describe this Item'
            name = 'comments'
            className = 'form-control'
            value = { this.state.comments }
            onChange = { this.onChange }
            /> < /
            div >

            <
            div className = 'form-group' >
            <
            input type = 'date'
            placeholder = 'date'
            name = 'date'
            className = 'form-control'
            value = { this.state.date }
            onChange = { this.onChange }
            /> < /
            div > <
            div className = 'form-group' >
            <
            input type = 'text'
            placeholder = 'Contact for this Item'
            name = 'contact'
            className = 'form-control'
            value = { this.state.contactr }
            onChange = { this.onChange }
            /> < /
            div >

            <
            input type = "submit"
            className = "btn btn-outline-warning btn-block mt-4" /
            >
            <
            /form> < /
            div > <
            /div> < /
            div > <
            /div>
        );
    }
}

export default CreateItemFound;