import React, { Fragment } from "react";

const CreateItemLost = () => ( <
    Fragment >
    <
    div class = "signup-form" >
    <
    p > under construction < /p> < /
    div >
    <
    /Fragment>
);

export default CreateItemLost;