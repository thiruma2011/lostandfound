import React, { Fragment } from "react";

const showItemListLost = () => ( <
    Fragment >
    <
    div class = "signup-form" >
    <
    p > under construction < /p> < /
    div >
    <
    /Fragment>
);

export default showItemListLost;