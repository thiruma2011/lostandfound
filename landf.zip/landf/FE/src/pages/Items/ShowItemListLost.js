import React, { Component } from 'react';
import './App.css';
import axios from 'axios';
import { Link } from 'react-router-dom';
import ItemCard from './ItemCard';

class ShowItemListLost extends Component {
    constructor(props) {
        super(props);
        this.state = {
            Items: []
        };
    }

    componentDidMount() {
        axios
            .get('http://localhost:4000/queryItemsLost')
            .then(res => {
                this.setState({
                    Items: res.data
                })
            })
            .catch(err => {
                console.log('Error from ShowItemListLost');
            })
    };


    render() {
        const Items = this.state.Items;
        console.log("PrintItem: " + Items);
        let ItemList;

        if (!Items) {
            ItemList = "there is no Lost Item recored!";
        } else {
            ItemList = Items.map((Item, k) =>
                <
                ItemCard Item = { Item }
                key = { k }
                />
            );
        }

        return ( <
            div className = "ShowItemList" >
            <
            div className = "container" >
            <
            div className = "row" >
            <
            div className = "col-md-12 m-auto" >
            <
            br / >
            <
            h2 className = "display-4 text-center" > List of Lost Items < /h2> < /
            div >

            <
            div className = "col-md-11" >
            <
            Link to = "/createitem"
            className = "btn btn-outline-warning float-right" >
            +Add New Item <
            /Link> <
            br / >
            <
            br / >
            <
            hr / >
            <
            /div>

            <
            /div>

            <
            div className = "list" > { ItemList } <
            /div> < /
            div > <
            /div>
        );
    }
}

export default ShowItemListLost;