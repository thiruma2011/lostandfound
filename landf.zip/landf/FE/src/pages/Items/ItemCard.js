import React from 'react';
import { Link } from 'react-router-dom';
import './App.css';

const ItemCard = (props) => {
    const Item = props.Item;

    return ( <
        div className = "card-container" >
        <
        img src = ""
        alt = "" / >
        <
        div className = "desc" >
        <
        h2 >
        <
        Link to = { `/viewItem/${Item._id}` } > { Item.category } <
        /Link> < /
        h2 > <
        h3 > { Item.title } < /h3> <
        p > { Item.description } < /p> < /
        div > <
        /div>
    )
};

export default ItemCard;