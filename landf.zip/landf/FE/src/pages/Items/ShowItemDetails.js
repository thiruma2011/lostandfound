import React, { Fragment } from "react";

const showItemDetails = () => ( <
    Fragment >
    <
    div class = "signup-form" >
    <
    p > under construction < /p> < /
    div >
    <
    /Fragment>
);

export default showItemDetails;