import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import '../App.css';
import axios from 'axios';


class CreateItem extends Component {
    constructor() {
        super();
        this.state = {
            title: '',
            category: '',
            description: '',
            status: '',
            timestamp: '',
            location: '',
            image: '',
            comments: ''
        };
    }

    onChange = e => {
        this.setState({
            [e.target.name]: e.target.value
        });
    };

    onSubmit = e => {
        e.preventDefault();

        const data = {
            title: this.state.title,
            category: this.state.category,
            description: this.state.description,
            status: this.state.status,
            timestamp: this.state.timestamp,

        };

        axios
            .post('http://localhost:8082/api/items', data)
            .then(res => {
                this.setState({
                    title: '',
                    category: '',
                    description: '',
                    status: '',
                    timestamp: '',
                    location: '',
                    image: '',
                    comments: ''
                })
                this.props.history.push('/');
            })
            .catch(err => {
                console.log("Error in CreateItem!");
            })
    };

    render() {
        return ( <
            div className = "CreateItem" >
            <
            div className = "container" >
            <
            div className = "row" >
            <
            div className = "col-md-8 m-auto" >
            <
            br / >
            <
            Link to = "/"
            className = "btn btn-warning float-left" >
            Show Item List <
            /Link> < /
            div > <
            div className = "col-md-8 m-auto" >
            <
            h1 className = "display-4 text-center" > Add Item < /h1> <
            p className = "lead text-center" >
            Create new item <
            /p>

            <
            form noValidate onSubmit = { this.onSubmit } >
            <
            div className = 'form-group' >
            <
            input type = 'text'
            placeholder = 'Title'
            name = 'title'
            className = 'form-control'
            value = { this.state.title }
            onChange = { this.onChange }
            /> < /
            div > <
            br / >
            <
            div className = 'form-group' >
            <
            input type = 'text'
            placeholder = 'Category'
            name = 'category'
            className = 'form-control'
            value = { this.state.category }
            onChange = { this.onChange }
            /> < /
            div > <
            br / >

            <
            div className = 'form-group' >
            <
            input type = 'text'
            placeholder = 'Description'
            name = 'description'
            className = 'form-control'
            value = { this.state.description }
            onChange = { this.onChange }
            /> < /
            div >
            <
            br / >

            <
            div className = 'form-group' >
            <
            input type = 'text'
            placeholder = 'Status'
            name = 'status'
            className = 'form-control'
            value = { this.state.status }
            onChange = { this.onChange }
            /> < /
            div >
            <
            br / >

            <
            div className = 'form-group' >
            <
            input type = 'date'
            placeholder = 'date'
            name = 'timestamp'
            className = 'form-control'
            value = { this.state.timestamp }
            onChange = { this.onChange }
            /> < /
            div >
            <
            br / >
            <
            div className = 'form-group' >
            <
            input type = 'text'
            placeholder = 'Location'
            name = 'location'
            className = 'form-control'
            value = { this.state.location }
            onChange = { this.onChange }
            /> < /
            div >
            <
            br / >
            <
            div className = 'form-group' >
            <
            input type = 'image'
            name = 'image'
            className = 'form-control'
            value = { this.state.image }
            onChange = { this.onChange }
            /> < /
            div >
            <
            br / >
            <
            div className = 'form-group' >
            <
            input type = 'text'
            placeholder = 'Comments'
            name = 'comments'
            className = 'form-control'
            value = { this.state.comments }
            onChange = { this.onChange }
            /> < /
            div >


            <
            input type = "submit"
            className = "btn btn-outline-warning btn-block mt-4" /
            >
            <
            /form> < /
            div > <
            /div> < /
            div > <
            /div>
        );
    }
}

export default CreateItem;