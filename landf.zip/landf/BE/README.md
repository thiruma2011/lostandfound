
### To Run the app (server)


```sh
$ npm install
$ npm run app
```
